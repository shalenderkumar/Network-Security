#!/bin/bash


HOST='192.168.43.220' #serverip
while true ; do cat /home/zerokelvin/aiw.txt > /dev/tcp/$HOST/9090; sleep 2; done &
USER='seed'
PASSWD='dees'
CMD='nc -l 9090 -v'

#CMD1='while true ; do sudo cat /home/ankit/Assignments/NetworkSecurity/tutorial_2b/alice_in_wonderland.txt > /dev/tcp/192.168.43.67/9090; sleep 2; done'

#echo "$CMD1"

(
echo open "$HOST"
sleep 2
echo "$USER"
sleep 2
echo "$PASSWD"
sleep 2
while true
do
echo "$CMD"
sleep 2
done &
)|telnet
